// Simple seed to create demo teams & players
import { PrismaClient } from "@prisma/client"
const prisma = new PrismaClient()

async function main(){
  const momentum = await prisma.team.create({
    data:{ name:"Momentum FC", captainCode:"momentum-1234" }
  })
  const anadolu = await prisma.team.create({ data:{ name:"Anadolu FC", captainCode:"anadolu-1234" } })
  const bahcesehir = await prisma.team.create({ data:{ name:"Bahçeşehir Gücü", captainCode:"bahcesehir-1234" } })

  await prisma.player.createMany({
    data:[
      { nickname:"Milvnn", position:"ST", teamId: momentum.id },
      { nickname:"SametWalker", position:"CDM", teamId: momentum.id },
      { nickname:"Vortex", position:"CAM", teamId: momentum.id },
      { nickname:"Eren", position:"CB", teamId: anadolu.id },
      { nickname:"Ahmet", position:"GK", teamId: bahcesehir.id },
    ]
  })
}
main().then(()=>prisma.$disconnect())
