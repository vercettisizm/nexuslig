# Nexus Lig Platform (MVP)

Tam teşekküllü **takım/oyuncu yönetimi**, **kaptan paneli**, **admin paneli**, **transfer** akışları ve **görsel yüklemeleri** içeren Next.js + Prisma (SQLite) tabanlı bir uygulama.

## Özellikler
- Oyuncu profili: avatar, banner, mevki, takım bağlantısı
- Takım sayfaları: logo, banner, oyuncu listesi
- Kaptan paneli: logo/banner yükleme, oyuncu ekleme, oyuncu görselleri
- Admin paneli: takım/oyuncu ekleme, transfer onay/red
- Transfer akışı: oyuncu → hedef takıma talep, admin onayı
- Yerel dosya yükleme: `public/uploads/`

## Kurulum
```bash
npm install
cp .env.example .env
npx prisma generate
npm run prisma:migrate
npm run dev
```

İsteğe bağlı seed:
```bash
node scripts/seed.js
```

### Paneller
- Admin: `/dashboard/admin?code=ADMIN_CODE` ( `.env` içindeki ADMIN_CODE ile )
- Kaptan: `/dashboard/team?teamId=...&code=TEAM_CAPTAIN_CODE`

### Notlar
- Bu MVP, hızlı başlamak içindir. Canlıda resim yüklemeyi S3 gibi bir storage’a taşıyın.
- Kimlik doğrulama için Discord OAuth entegre edilebilir (NextAuth).


## Vercel + Neon (PostgreSQL) Hızlı Deploy
1) https://neon.tech ile ücretsiz bir Postgres DB açın ve `DATABASE_URL` alın.
2) Bu repo’yu GitHub’a yükleyin, Vercel’de “New Project → Import” deyin.
3) Vercel’de `Environment Variables` ekleyin:
   - `DATABASE_URL` = (Neon bağlantı adresi)
   - `ADMIN_CODE` = kendi admin kodunuz
4) Vercel “Build & Deploy” sonrası konsolda:
   - `npx prisma migrate deploy` komutu için Vercel Post-Deploy Command ayarlayabilirsiniz.
5) Admin panel: `/dashboard/admin?code=ADMIN_CODE`
