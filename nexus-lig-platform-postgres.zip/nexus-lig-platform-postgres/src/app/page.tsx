import Link from "next/link"

export default function Home(){
  return (
    <section className="hero relative">
      <div className="max-w-7xl mx-auto px-4 py-16 md:py-20 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-4xl md:text-6xl font-extrabold leading-tight">
            EA FC 26 <span className="text-nxred">Nexus Lig</span>
          </h1>
          <p className="mt-4 text-gray-300 md:text-lg">
            16 takımlı, haftalık fikstürlü, anime/esports ruhunu taşıyan rekabetçi Clubs ligi.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/teams" className="px-5 py-3 rounded-lg bg-white text-black font-semibold hover:bg-gray-200">Takımları Gör</Link>
            <Link href="/dashboard" className="px-5 py-3 rounded-lg border border-white/20 hover:border-white/40">Yönetim Paneli</Link>
          </div>
        </div>
        <div className="relative">
          <div className="w-full aspect-[4/3] rounded-2xl card overflow-hidden glow grid place-items-center text-gray-400">
            <span>Buraya hero görseli ekleyebilirsiniz.</span>
          </div>
        </div>
      </div>
      <div className="h-px max-w-7xl mx-auto bg-gradient-to-r from-transparent via-white/15 to-transparent" />
    </section>
  )
}
