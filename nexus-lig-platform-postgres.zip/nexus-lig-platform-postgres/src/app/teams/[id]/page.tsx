import { prisma } from "@/lib/prisma"
import Image from "next/image"
import Link from "next/link"

export default async function TeamDetail({ params }:{ params:{ id:string }}){
  const team = await prisma.team.findUnique({ where:{ id: params.id }, include:{ players:true } })
  if(!team) return <div className="max-w-7xl mx-auto px-4 py-10">Takım bulunamadı.</div>

  return (
    <section className="max-w-6xl mx-auto px-4 py-10">
      <div className="rounded-2xl overflow-hidden card">
        <div className="h-44 w-full bg-black/40 relative">
          {team.bannerUrl && <Image src={team.bannerUrl} alt="banner" fill className="object-cover" />}
        </div>
        <div className="p-4 md:p-6">
          <div className="flex items-center gap-4">
            <div className="h-20 w-20 rounded-lg overflow-hidden bg-white/10 grid place-items-center -mt-14 border border-white/20">
              {team.logoUrl ? <Image src={team.logoUrl} alt={team.name} width={96} height={96} className="object-contain w-full h-full" /> : <span className="text-xs text-gray-400">Logo</span>}
            </div>
            <div>
              <h1 className="text-2xl font-extrabold">{team.name}</h1>
              <div className="text-sm text-gray-400">{team.players.length} oyuncu</div>
            </div>
            <div className="ml-auto">
              <Link href={`/dashboard/team?teamId=${team.id}`} className="text-sm text-gray-300 hover:text-white">Kaptan Paneli →</Link>
            </div>
          </div>

          <div className="mt-6">
            <h3 className="font-bold mb-3">Kadro</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {team.players.map(p => (
                <Link key={p.id} href={`/players/${p.id}`} className="card rounded-lg p-3 hover:border-white/30">
                  <div className="h-20 w-full bg-black/40 rounded grid place-items-center overflow-hidden">
                    {p.avatarUrl ? <Image src={p.avatarUrl} alt={p.nickname} width={80} height={80} className="object-cover" /> : <span className="text-[10px] text-gray-400">PF</span>}
                  </div>
                  <div className="mt-2 font-semibold">{p.nickname}</div>
                  <div className="text-xs text-gray-400">{p.position || "Mevki yok"}</div>
                </Link>
              ))}
              {team.players.length === 0 && <div className="text-sm text-gray-400">Henüz oyuncu eklenmemiş.</div>}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
