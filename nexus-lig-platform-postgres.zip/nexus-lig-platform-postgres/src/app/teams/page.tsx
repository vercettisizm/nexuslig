import { prisma } from "@/lib/prisma"
import Link from "next/link"
import Image from "next/image"

export default async function TeamsPage(){
  const teams = await prisma.team.findMany({ orderBy: { createdAt: "desc" }, include: { players: true } })
  return (
    <section className="max-w-7xl mx-auto px-4 py-10">
      <div className="flex items-end justify-between mb-6">
        <h2 className="text-2xl md:text-3xl font-extrabold">Takımlar</h2>
        <Link href="/dashboard/admin" className="text-sm text-gray-400 hover:text-white">(+ Admin) Takım Ekle</Link>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {teams.map(t => (
          <Link key={t.id} href={`/teams/${t.id}`} className="card rounded-xl p-4 hover:border-white/30 transition">
            <div className="h-16 w-full grid place-items-center bg-black/40 rounded-lg overflow-hidden">
              {t.logoUrl ? <Image src={t.logoUrl} alt={t.name} width={120} height={64} className="object-contain" /> : <span className="text-xs text-gray-500">Logo Yok</span>}
            </div>
            <div className="mt-3 font-semibold">{t.name}</div>
            <div className="text-xs text-gray-400">{t.players.length} oyuncu</div>
          </Link>
        ))}
      </div>
    </section>
  )
}
