import { prisma } from "@/lib/prisma"
import Image from "next/image"
import Link from "next/link"

export default async function PlayerDetail({ params }:{ params:{ id:string }}){
  const player = await prisma.player.findUnique({ where:{ id: params.id }, include:{ team:true } })
  if(!player) return <div className="max-w-7xl mx-auto px-4 py-10">Oyuncu bulunamadı.</div>
  return (
    <section className="max-w-5xl mx-auto px-4 py-10">
      <div className="rounded-2xl overflow-hidden card">
        <div className="h-40 md:h-56 w-full bg-black/40 relative">
          {player.bannerUrl && <Image src={player.bannerUrl} alt="banner" fill className="object-cover" />}
        </div>
        <div className="p-4 md:p-6">
          <div className="flex items-center gap-4">
            <div className="h-20 w-20 rounded-full overflow-hidden bg-white/10 grid place-items-center -mt-14 border border-white/20">
              {player.avatarUrl ? <Image src={player.avatarUrl} alt={player.nickname} width={80} height={80} className="object-cover w-full h-full" /> : <span className="text-xs text-gray-400">PF</span>}
            </div>
            <div>
              <h1 className="text-2xl font-extrabold">{player.nickname}</h1>
              <div className="text-sm text-gray-400">{player.position || "Mevki yok"}</div>
            </div>
            <div className="ml-auto">
              {player.team && <Link href={`/teams/${player.team.id}`} className="text-sm text-gray-300 hover:text-white">Takımı Gör → {player.team.name}</Link>}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
