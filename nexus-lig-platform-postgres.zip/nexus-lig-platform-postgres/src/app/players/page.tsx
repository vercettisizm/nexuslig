import { prisma } from "@/lib/prisma"
import Link from "next/link"
import Image from "next/image"

export default async function PlayersPage(){
  const players = await prisma.player.findMany({
    orderBy: { createdAt: "desc" },
    include: { team: true }
  })
  return (
    <section className="max-w-7xl mx-auto px-4 py-10">
      <div className="flex items-end justify-between mb-6">
        <h2 className="text-2xl md:text-3xl font-extrabold">Oyuncular</h2>
        <Link href="/dashboard/admin" className="text-sm text-gray-400 hover:text-white">(+ Admin) Oyuncu Ekle</Link>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {players.map(p => (
          <Link key={p.id} href={`/players/${p.id}`} className="card rounded-xl p-3 hover:border-white/30 transition">
            <div className="aspect-video rounded-lg overflow-hidden bg-black/40 grid place-items-center">
              {p.bannerUrl ? (
                <Image src={p.bannerUrl} alt={p.nickname} width={320} height={180} className="w-full h-full object-cover" />
              ) : <span className="text-xs text-gray-500">Banner Yok</span>}
            </div>
            <div className="flex items-center gap-3 mt-3">
              <div className="h-10 w-10 rounded-full overflow-hidden bg-white/10 grid place-items-center">
                {p.avatarUrl ? <Image src={p.avatarUrl} alt={p.nickname} width={40} height={40} className="object-cover w-full h-full" /> : <span className="text-[10px] text-gray-400">PF</span>}
              </div>
              <div>
                <div className="font-semibold">{p.nickname}</div>
                <div className="text-xs text-gray-400">{p.position || "Mevki yok"} {p.team ? `• ${p.team.name}` : ""}</div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  )
}
