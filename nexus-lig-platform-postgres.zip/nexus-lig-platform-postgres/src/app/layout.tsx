import "./globals.css"
import type { Metadata } from "next"
import Navbar from "@/components/Navbar"

export const metadata: Metadata = {
  title: "Nexus Lig — Esports Clubs Ligi",
  description: "Oyuncu profilleri, takım sayfaları, kaptan paneli ve yönetim konsolu ile Nexus Lig platformu.",
}

export default function RootLayout({ children }: { children: React.ReactNode }){
  return (
    <html lang="tr">
      <body>
        <Navbar />
        <main>{children}</main>
      </body>
    </html>
  )
}
