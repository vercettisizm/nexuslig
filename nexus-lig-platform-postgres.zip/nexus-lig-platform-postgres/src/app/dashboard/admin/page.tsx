import { prisma } from "@/lib/prisma"
import { createTeam, createPlayer, movePlayer, decideTransfer } from "./actions"

export const dynamic = "force-dynamic"

export default async function AdminPage({ searchParams }:{ searchParams:{ code?:string }}){
  const code = searchParams.code || ""
  const adminOk = code === (process.env.ADMIN_CODE || "changeme-admin-1234")

  const teams = await prisma.team.findMany({ include:{ players:true } })
  const players = await prisma.player.findMany({ include:{ team:true } })
  const transfers = await prisma.transferRequest.findMany({ include:{ player:true, fromTeam:true, toTeam:true }, orderBy:{ createdAt:"desc" } })

  if(!adminOk){
    return (
      <section className="max-w-2xl mx-auto px-4 py-10">
        <h2 className="text-2xl font-extrabold">Admin Girişi</h2>
        <p className="text-gray-400 text-sm mt-2">Admin paneline erişmek için URL’ye <code>?code=ADMIN_KODU</code> ekleyin.</p>
      </section>
    )
  }

  return (
    <section className="max-w-7xl mx-auto px-4 py-10 space-y-10">
      <div className="grid md:grid-cols-2 gap-6">
        <form action={createTeam} className="card rounded-2xl p-5 space-y-3">
          <h3 className="font-bold">Takım Ekle</h3>
          <input name="name" placeholder="Takım adı" className="w-full px-3 py-2 rounded bg-black/30 border border-white/10" />
          <input name="captainCode" placeholder="Kaptan panel kodu (opsiyonel)" className="w-full px-3 py-2 rounded bg-black/30 border border-white/10" />
          <button className="px-4 py-2 rounded bg-white text-black font-semibold">Ekle</button>
        </form>

        <form action={createPlayer} className="card rounded-2xl p-5 space-y-3">
          <h3 className="font-bold">Oyuncu Ekle</h3>
          <input name="nickname" placeholder="Oyuncu adı" className="w-full px-3 py-2 rounded bg-black/30 border border-white/10" />
          <input name="position" placeholder="Mevki (ST, CAM, CDM...)" className="w-full px-3 py-2 rounded bg-black/30 border border-white/10" />
          <select name="teamId" className="w-full px-3 py-2 rounded bg-black/30 border border-white/10">
            <option value="">Takımsız</option>
            {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          <button className="px-4 py-2 rounded bg-white text-black font-semibold">Ekle</button>
        </form>
      </div>

      <div className="card rounded-2xl p-5">
        <h3 className="font-bold mb-3">Transfer Talepleri</h3>
        <div className="space-y-2">
          {transfers.length === 0 && <div className="text-sm text-gray-400">Bekleyen talep yok</div>}
          {transfers.map(tr => (
            <form key={tr.id} action={decideTransfer} className="flex items-center gap-3 p-3 rounded bg-black/30">
              <input type="hidden" name="id" value={tr.id} />
              <div className="text-sm">
                <span className="font-semibold">{tr.player.nickname}</span>: {tr.fromTeam?.name || "Takımsız"} → {tr.toTeam?.name || "?"} ({tr.status})
              </div>
              <button name="decision" value="APPROVE" className="ml-auto px-3 py-1 rounded bg-white text-black text-sm">Onayla</button>
              <button name="decision" value="REJECT" className="px-3 py-1 rounded border border-white/20 text-sm">Reddet</button>
            </form>
          ))}
        </div>
      </div>

      <div className="card rounded-2xl p-5">
        <h3 className="font-bold mb-3">Hızlı İşlemler</h3>
        <form action={movePlayer} className="grid md:grid-cols-4 gap-3">
          <select name="playerId" className="px-3 py-2 rounded bg-black/30 border border-white/10">
            {players.map(p => <option key={p.id} value={p.id}>{p.nickname} ({p.team?.name || "Takımsız"})</option>)}
          </select>
          <select name="toTeamId" className="px-3 py-2 rounded bg-black/30 border border-white/10">
            <option value="">Takımsız</option>
            {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          <button className="px-4 py-2 rounded bg-white text-black font-semibold">Taşı</button>
        </form>
      </div>
    </section>
  )
}
