'use server'

import { prisma } from "@/lib/prisma"
import { revalidatePath } from "next/cache"
import { writeFile } from "fs/promises"
import path from "path"

export async function createTeam(formData: FormData){
  const name = String(formData.get("name") || "")
  const captainCode = String(formData.get("captainCode") || "")
  if(!name) return { ok:false, error:"Takım adı gerekli" }
  const team = await prisma.team.create({ data:{ name, captainCode } })
  revalidatePath("/teams")
  return { ok:true, id: team.id }
}

export async function uploadTeamAssets(formData: FormData){
  const teamId = String(formData.get("teamId") || "")
  const logo = formData.get("logo") as File | null
  const banner = formData.get("banner") as File | null
  const updates: any = {}
  const uploadDir = path.join(process.cwd(), "public", "uploads")

  if(logo && logo.size > 0){
    const buf = Buffer.from(await logo.arrayBuffer())
    const filePath = path.join(uploadDir, `team-${teamId}-logo-${Date.now()}.png`)
    await writeFile(filePath, buf)
    updates.logoUrl = "/uploads/" + path.basename(filePath)
  }
  if(banner && banner.size > 0){
    const buf = Buffer.from(await banner.arrayBuffer())
    const filePath = path.join(uploadDir, `team-${teamId}-banner-${Date.now()}.png`)
    await writeFile(filePath, buf)
    updates.bannerUrl = "/uploads/" + path.basename(filePath)
  }

  await prisma.team.update({ where:{ id: teamId }, data: updates })
  revalidatePath(`/teams/${teamId}`)
  revalidatePath("/teams")
  return { ok:true }
}

export async function createPlayer(formData: FormData){
  const nickname = String(formData.get("nickname") || "")
  const position = String(formData.get("position") || "")
  const teamId = String(formData.get("teamId") || "") || null
  if(!nickname) return { ok:false, error:"Oyuncu adı gerekli" }
  const player = await prisma.player.create({ data:{ nickname, position: position || null, teamId: teamId || null } })
  revalidatePath("/players")
  if(teamId) revalidatePath(`/teams/${teamId}`)
  return { ok:true, id: player.id }
}

export async function uploadPlayerAssets(formData: FormData){
  const playerId = String(formData.get("playerId") || "")
  const avatar = formData.get("avatar") as File | null
  const banner = formData.get("banner") as File | null
  const updates: any = {}
  const uploadDir = path.join(process.cwd(), "public", "uploads")
  if(avatar && avatar.size > 0){
    const buf = Buffer.from(await avatar.arrayBuffer())
    const filePath = path.join(uploadDir, `player-${playerId}-avatar-${Date.now()}.png`)
    await writeFile(filePath, buf)
    updates.avatarUrl = "/uploads/" + path.basename(filePath)
  }
  if(banner && banner.size > 0){
    const buf = Buffer.from(await banner.arrayBuffer())
    const filePath = path.join(uploadDir, `player-${playerId}-banner-${Date.now()}.png`)
    await writeFile(filePath, buf)
    updates.bannerUrl = "/uploads/" + path.basename(filePath)
  }
  await prisma.player.update({ where:{ id: playerId }, data: updates })
  revalidatePath(`/players/${playerId}`)
  revalidatePath("/players")
  return { ok:true }
}

export async function movePlayer(formData: FormData){
  const playerId = String(formData.get("playerId") || "")
  const toTeamId = String(formData.get("toTeamId") || "") || null
  const player = await prisma.player.update({ where:{ id: playerId }, data:{ teamId: toTeamId || null } })
  revalidatePath("/players")
  if(toTeamId) revalidatePath(`/teams/${toTeamId}`)
  if(player.teamId) revalidatePath(`/teams/${player.teamId}`)
  return { ok:true }
}

export async function requestTransfer(formData: FormData){
  const playerId = String(formData.get("playerId") || "")
  const toTeamId = String(formData.get("toTeamId") || "")
  const player = await prisma.player.findUnique({ where:{ id: playerId } })
  const req = await prisma.transferRequest.create({
    data:{
      playerId,
      fromTeamId: player?.teamId || null,
      toTeamId,
      status: "PENDING"
    }
  })
  revalidatePath("/dashboard/admin")
  return { ok:true }
}

export async function decideTransfer(formData: FormData){
  const id = String(formData.get("id") || "")
  const decision = String(formData.get("decision") || "REJECT")
  const req = await prisma.transferRequest.findUnique({ where:{ id } })
  if(!req) return { ok:false }
  if(decision === "APPROVE"){
    await prisma.$transaction([
      prisma.transferRequest.update({ where:{ id }, data:{ status:"APPROVE" } }),
      prisma.player.update({ where:{ id: req.playerId }, data:{ teamId: req.toTeamId } })
    ])
  } else {
    await prisma.transferRequest.update({ where:{ id }, data:{ status:"REJECT" } })
  }
  revalidatePath("/dashboard/admin")
  return { ok:true }
}
