import { prisma } from "@/lib/prisma"
import { uploadTeamAssets, createPlayer, uploadPlayerAssets, movePlayer, requestTransfer } from "../actions"
import Upload from "@/components/Upload"

export const dynamic = "force-dynamic"

export default async function CaptainPage({ searchParams }:{ searchParams:{ teamId?:string, code?:string }}){
  const teamId = searchParams.teamId
  const code = searchParams.code || ""
  if(!teamId) return <div className="max-w-2xl mx-auto px-4 py-10">teamId parametresi gerekli.</div>
  const team = await prisma.team.findUnique({ where:{ id: teamId }, include:{ players:true } })
  if(!team) return <div className="max-w-2xl mx-auto px-4 py-10">Takım bulunamadı.</div>

  const captainOk = code && team.captainCode && code === team.captainCode

  return (
    <section className="max-w-7xl mx-auto px-4 py-10 space-y-8">
      <h2 className="text-2xl md:text-3xl font-extrabold">{team.name} — Kaptan Paneli</h2>
      {!captainOk && (
        <div className="card rounded-xl p-4 text-sm text-gray-300">
          Bu panelde değişiklik yapabilmek için URL'ye <code>?teamId={team.id}&code=KAPTAN_KODU</code> ekleyin. (Kodu admin panelinden belirleyin.)
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-6">
        <form action={uploadTeamAssets} className="card rounded-xl p-5 space-y-3">
          <h3 className="font-bold mb-1">Logo / Banner</h3>
          <input type="hidden" name="teamId" value={team.id} />
          <Upload label="Logo" name="logo" />
          <Upload label="Banner" name="banner" />
          <button disabled={!captainOk} className="px-4 py-2 rounded bg-white text-black font-semibold disabled:opacity-50">Kaydet</button>
        </form>

        <form action={createPlayer} className="card rounded-xl p-5 space-y-3">
          <h3 className="font-bold mb-1">Oyuncu Ekle</h3>
          <input name="nickname" placeholder="Oyuncu adı" className="w-full px-3 py-2 rounded bg-black/30 border border-white/10" />
          <input name="position" placeholder="Mevki (ST, CAM, CDM...)" className="w-full px-3 py-2 rounded bg-black/30 border border-white/10" />
          <input type="hidden" name="teamId" value={team.id} />
          <button disabled={!captainOk} className="px-4 py-2 rounded bg-white text-black font-semibold disabled:opacity-50">Ekle</button>
        </form>
      </div>

      <div className="card rounded-xl p-5">
        <h3 className="font-bold mb-3">Kadro Yönetimi</h3>
        <div className="space-y-3">
          {team.players.map(p => (
            <form key={p.id} action={uploadPlayerAssets} className="grid md:grid-cols-5 gap-3 items-end bg-black/30 rounded p-3">
              <input type="hidden" name="playerId" value={p.id} />
              <div>
                <div className="text-xs text-gray-400">Oyuncu</div>
                <div className="font-semibold">{p.nickname}</div>
                <div className="text-xs text-gray-400">{p.position || "Mevki yok"}</div>
              </div>
              <div className="md:col-span-2">
                <div className="text-xs text-gray-400 mb-1">Avatar</div>
                <input type="file" name="avatar" />
              </div>
              <div className="md:col-span-2">
                <div className="text-xs text-gray-400 mb-1">Banner</div>
                <input type="file" name="banner" />
              </div>
              <div className="md:col-span-5 flex gap-3">
                <select name="toTeamId" className="px-3 py-2 rounded bg-black/30 border border-white/10">
                  <option value="">Takımsız</option>
                  {/* Takım değişimi için admin panelini kullanın ya da transfer isteği oluşturun */}
                </select>
                <button formAction={uploadPlayerAssets} disabled={!captainOk} className="px-3 py-2 rounded bg-white text-black text-sm font-semibold disabled:opacity-50">Görselleri Kaydet</button>
              </div>
            </form>
          ))}
          {team.players.length === 0 && <div className="text-sm text-gray-400">Kadro boş. Oyuncu ekleyin.</div>}
        </div>
      </div>

      <div className="card rounded-xl p-5">
        <h3 className="font-bold mb-3">Transfer Talebi Oluştur</h3>
        <form action={requestTransfer} className="grid md:grid-cols-4 gap-3">
          <input name="playerId" placeholder="Oyuncu ID" className="px-3 py-2 rounded bg-black/30 border border-white/10" />
          <input name="toTeamId" placeholder="Hedef Takım ID" className="px-3 py-2 rounded bg-black/30 border border-white/10" />
          <button className="px-4 py-2 rounded bg-white text-black font-semibold disabled:opacity-50">İsteği Gönder</button>
        </form>
        <div className="text-xs text-gray-400 mt-2">Not: Admin paneli talepleri onaylar.</div>
      </div>
    </section>
  )
}
