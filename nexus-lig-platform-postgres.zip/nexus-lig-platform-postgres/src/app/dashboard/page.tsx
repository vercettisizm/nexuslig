import Link from "next/link"

export default function Dashboard(){
  return (
    <section className="max-w-7xl mx-auto px-4 py-10">
      <h2 className="text-2xl md:text-3xl font-extrabold mb-4">Yönetim Paneli</h2>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="card rounded-xl p-5">
          <h3 className="font-bold">Admin Konsolu</h3>
          <p className="text-gray-400 text-sm mt-1">Takımlar / oyuncular / transferler.</p>
          <Link href="/dashboard/admin" className="mt-4 inline-block px-4 py-2 rounded-lg bg-white text-black font-semibold">Git</Link>
        </div>
        <div className="card rounded-xl p-5">
          <h3 className="font-bold">Kaptan Paneli</h3>
          <p className="text-gray-400 text-sm mt-1">Kendi takımını yönet.</p>
          <Link href="/dashboard/team" className="mt-4 inline-block px-4 py-2 rounded-lg border border-white/20">Git</Link>
        </div>
      </div>
    </section>
  )
}
