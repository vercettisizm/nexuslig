'use client'
import { useRef, useState } from "react"

export default function Upload({label, name}:{label:string,name:string}){
  const [fileName, setFileName] = useState<string>("")
  const inputRef = useRef<HTMLInputElement>(null)
  return (
    <div className="space-y-2">
      <label className="text-sm text-gray-300">{label}</label>
      <div className="flex items-center gap-3">
        <input ref={inputRef} type="file" name={name} className="text-sm" onChange={(e)=>{
          setFileName(e.target.files?.[0]?.name || "")
        }} />
        {fileName && <span className="text-xs text-gray-400">{fileName}</span>}
      </div>
    </div>
  )
}
