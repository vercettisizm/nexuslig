import Link from "next/link"
import Image from "next/image"

export default function Navbar(){
  return (
    <header className="sticky top-0 z-40 bg-black/50 backdrop-blur border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Image src="/nexus-lig-logo.png" alt="Nexus Lig" width={56} height={56} className="rounded-lg object-contain" />
          <span className="font-extrabold tracking-widest text-white">NEXUS LIG</span>
          <span className="text-xs px-2 py-1 rounded border border-white/15 ml-3 text-gray-300">FC26 • Clubs</span>
        </div>
        <nav className="hidden md:flex items-center gap-6 text-sm text-gray-300">
          <Link href="/teams" className="hover:text-white">Takımlar</Link>
          <Link href="/players" className="hover:text-white">Oyuncular</Link>
          <Link href="/dashboard" className="hover:text-white">Panel</Link>
        </nav>
      </div>
    </header>
  )
}
